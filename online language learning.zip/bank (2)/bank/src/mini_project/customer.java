package mini_project;

import java.util.*;
import java.sql.*;

// Step 1: Create an interface for BankAccount
interface User {
    void createAccount();
}

// Step 2: Make the customer class implement the BankAccount interface
public class customer implements User {

    private String name;
    private long mobile_number;
    private String email;
    private Connection con;
    private JDBC jd = new JDBC();

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(long mobile_number) {
        this.mobile_number = mobile_number;
    }

    // Step 3: Implement the createAccount() method from the BankAccount interface
    @Override
    public void createAccount() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name: ");
        name = sc.nextLine();

        System.out.println("Enter mobile number: ");
        mobile_number = sc.nextLong();
        sc.nextLine(); // Consume the newline left by nextLong()

        System.out.println("Enter email: ");
        email = sc.nextLine();

        try {
            con = jd.getcon(); // Assuming you have a method in the JDBC class to get the connection

            // Check if the name already exists in the table
            PreparedStatement checkStatement = con.prepareStatement("SELECT COUNT(*) FROM user_login WHERE name = ?");
            checkStatement.setString(1, name);
            ResultSet checkResult = checkStatement.executeQuery();
            checkResult.next();
            int rowCount = checkResult.getInt(1);

            System.out.println("Row count for name '" + name + "': " + rowCount);

            if (rowCount > 0) {
                // Name already exists, update the mobile number and email
                PreparedStatement updateStatement = con.prepareStatement("UPDATE user_login SET mobile_number = ?, email = ? WHERE name = ?");
                updateStatement.setLong(1, mobile_number);
                updateStatement.setString(2, email);
                updateStatement.setString(3, name);

                int rowsAffected = updateStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Account updated successfully!");
                } else {
                    System.out.println("Failed to update the account.");
                }
            } else {
                // Name doesn't exist, insert a new record
                PreparedStatement insertStatement = con.prepareStatement("INSERT INTO user_login (name, mobile_number, email) VALUES (?, ?, ?)");
                insertStatement.setString(1, name);
                insertStatement.setLong(2, mobile_number);
                insertStatement.setString(3, email);

                int rowsAffected = insertStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Account created successfully!");
                } else {
                    System.out.println("Failed to create an account.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void deleteAccountByName() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the name to delete the account: ");
        String deleteName = sc.nextLine();

        try {
            con = jd.getcon(); // Assuming you have a method in the JDBC class to get the connection

            // Check if the name exists in the table
            PreparedStatement checkStatement = con.prepareStatement("SELECT COUNT(*) FROM user_login WHERE name = ?");
            checkStatement.setString(1, deleteName);
            ResultSet checkResult = checkStatement.executeQuery();
            checkResult.next();
            int rowCount = checkResult.getInt(1);

            if (rowCount > 0) {
                // Name exists, delete the record
                PreparedStatement deleteStatement = con.prepareStatement("DELETE FROM user_login WHERE name = ?");
                deleteStatement.setString(1, deleteName);

                int rowsAffected = deleteStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Account for '" + deleteName + "' deleted successfully!");
                } else {
                    System.out.println("Failed to delete the account for '" + deleteName + "'.");
                }
            } else {
                System.out.println("No account found for name '" + deleteName + "'.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void updateAccountByName() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the name to update the account: ");
        String updateName = sc.nextLine();

        try {
            con = jd.getcon(); // Assuming you have a method in the JDBC class to get the connection

            // Check if the name exists in the table
            PreparedStatement checkStatement = con.prepareStatement("SELECT COUNT(*) FROM user_login WHERE name = ?");
            checkStatement.setString(1, updateName);
            ResultSet checkResult = checkStatement.executeQuery();
            checkResult.next();
            int rowCount = checkResult.getInt(1);

            if (rowCount > 0) {
                System.out.println("Enter new mobile number: ");
                long newMobileNumber = sc.nextLong();
                sc.nextLine(); // Consume the newline left by nextLong()

                System.out.println("Enter new email: ");
                String newEmail = sc.nextLine();

                // Update the record with the new mobile number and email
                PreparedStatement updateStatement = con.prepareStatement("UPDATE user_login SET mobile_number = ?, email = ? WHERE name = ?");
                updateStatement.setLong(1, newMobileNumber);
                updateStatement.setString(2, newEmail);
                updateStatement.setString(3, updateName);

                int rowsAffected = updateStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Account for '" + updateName + "' updated successfully!");
                } else {
                    System.out.println("Failed to update the account for '" + updateName + "'.");
                }
            } else {
                System.out.println("No account found for name '" + updateName + "'.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
