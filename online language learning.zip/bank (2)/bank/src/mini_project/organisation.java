package mini_project;
import java.util.*;

public class organisation {
	
	public static void main(String [] args)
	{
		int option=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to melvin's the learning app");
		while(true)
		{
			
			System.out.println("Enter 1--->Login as User\nEnter 2--->Login as Admin\nEnter 3--->Enter the language you wanna learn\nEnter 4--->Check fee details\nEnter 5--->Exit The Application\nEnter 6--->delete\nEnter 7--->Update");
			option=sc.nextInt()	;
			if(option==1)
			{
				System.out.println("---------Enter your Details--------");
				customer s=new customer();
				s.createAccount();
				System.out.println("Your details is successfully added.");
				System.out.println("-------------------------------------");
				System.out.println();
			}
			else if(option==2)
			{
				System.out.println("--------Enter the required details--------");
				Admin e=new Admin();
				e.learning();
				System.out.println("Admin stored successfully");
				System.out.println("-------------------------------------");
				System.out.println();
			}
			else if(option==3)
			{
				System.out.println("--------Enter the required details--------");
				withdraw w=new withdraw();
				w.searchLanguage();
				System.out.println("Found Successfully");
				System.out.println("-------------------------------------");
				System.out.println();
			}
			else if(option==4)
			{
				System.out.println("--------Enter the required details--------");
				balance b=new balance();
				b.searchLanguage(1);
				System.out.println("This is your expense for 10 months");
				System.out.println("-------------------------------------");
				System.out.println();
			}
//			else if(option==5)
//			{
//				System.out.println("--------Enter the required details--------");
//				fund_transfer f=new fund_transfer();
//				f.performFundTransfer();
//				System.out.println("Fund Transfer done successfully");
//				System.out.println("-------------------------------------");
//				System.out.println();
//			}
			else if(option==4)
			{
				System.out.print("Thank You For Visting");
				System.exit(0);
			}
			else if(option==6)
			{System.out.println("--------Enter the required details--------");
			customer b1=new customer();
			b1.deleteAccountByName();
//			System.out.println("This is your expense for 10 months");
			System.out.println("-------------------------------------");
			System.out.println();
				
			}
			else if(option==7)
			{System.out.println("--------Enter the required details--------");
			customer b2=new customer();
			b2.updateAccountByName();
//			System.out.println("This is your expense for 10 months");
			System.out.println("-------------------------------------");
			System.out.println();
				
			}
			else 
			{
				System.out.println("Invalid input");
			}
			
		}
	}
	

}