package mini_project;

import java.util.*;
import java.sql.*;
abstract class learn{
	public abstract void learning();
}
public class Admin extends learn {

	private String name;
    private long mobile_number;
    private String email;
    private String language;
    private long payment;
    public long getPayment() {
		return payment;
	}

	public void setPayment(long payment) {
		this.payment = payment;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}



	private Connection con;
    private JDBC jd = new JDBC();

    

    public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(long mobile_number) {
        this.mobile_number = mobile_number;
    }

   

    // Step 3: Implement the createAccount() method from the BankAccount interface
    
    public void learning() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name: ");
        String name = sc.nextLine();

        System.out.println("Enter mobile number: ");
        long mobile_number = sc.nextLong();
        sc.nextLine(); // Consume the newline left by nextLong()

        
        System.out.println("Enter email: ");
        String email = sc.nextLine();
        System.out.println("Enter the language you are skilled: ");
        String language = sc.nextLine();
        System.out.println("Enter your expected payment ");
        long payment = sc.nextLong();
        sc.nextLine();

        try {
            con = jd.getcon(); // Assuming you have a method in the JDBC class to get the connection
            PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO admin_login1 (name, mobile_number, email,language,payment) VALUES (?, ?, ?,?,?)");
            preparedStatement.setString(1, name);
            preparedStatement.setLong(2, mobile_number);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, language);
            preparedStatement.setLong(5, payment);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Account created successfully!");
            } else {
                System.out.println("Failed to create an account.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


	
    
}
