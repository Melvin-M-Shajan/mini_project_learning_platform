package mini_project;
import java.util.*;
import java.sql.*;

public class fund_transfer{
	
	 protected long s_acc_no;
	    protected long r_acc_no;
	    protected long depo;
	    protected Connection con;
	    JDBC jd = new JDBC();

	    public void performFundTransfer() {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter your account number:");
	        this.s_acc_no = sc.nextLong();
	        System.out.println("Enter receiver account number:");
	        this.r_acc_no = sc.nextLong();
	        System.out.println("Enter the money to be transferred:");
	        this.depo = sc.nextLong();

	        try {
	            con = jd.getcon();

	            // Check if the sender's account has sufficient balance for the transfer
	            PreparedStatement psSender = con.prepareStatement("SELECT current_bal FROM bal WHERE account_no = ?");
	            psSender.setLong(1, s_acc_no);
	            ResultSet rsSender = psSender.executeQuery();

	            if (rsSender.next()) {
	                long senderCurrentBalance = rsSender.getLong("current_bal");
	                if (senderCurrentBalance >= depo) {
	                    // Sufficient balance, perform the fund transfer
	                    PreparedStatement psReceiver = con.prepareStatement("UPDATE bal SET current_bal = current_bal + ? WHERE account_no = ?");
	                    psReceiver.setLong(1, depo);
	                    psReceiver.setLong(2, r_acc_no);
	                    psReceiver.executeUpdate();

	                    PreparedStatement psUpdateSender = con.prepareStatement("UPDATE bal SET current_bal = current_bal - ? WHERE account_no = ?");
	                    psUpdateSender.setLong(1, depo);
	                    psUpdateSender.setLong(2, s_acc_no);
	                    psUpdateSender.executeUpdate();

	                    System.out.println("Fund transfer successful.");
	                    System.out.println("===== Fund Transfer Bill =====");
	                    System.out.println("Sender's Account: " + s_acc_no);
	                    System.out.println("Receiver's Account: " + r_acc_no);
	                    System.out.println("Amount Transferred: " + depo);
	                    System.out.println("==============================");

	                    System.out.println("Fund transfer successful.");

	                } else {
	                    System.out.println("Insufficient balance in the sender's account.");
	                }
	            } else {
	                System.out.println("Sender's account not found.");
	            }

	            rsSender.close();
	            psSender.close();
	            con.close();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	    }}