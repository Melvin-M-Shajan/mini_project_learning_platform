package mini_project;
import java.util.*;
import java.sql.*;

public class balance extends withdraw{
	
	
	private Connection con;
	JDBC jd=new JDBC();
	
	public void searchLanguage(int n) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the tutor name :");
		
		try
		{
			con=jd.getcon();
			PreparedStatement ps1 = con.prepareStatement("SELECT payment FROM admin_login1 WHERE name = ?");
			ps1.setString(1, sc.nextLine());

			ResultSet rs = ps1.executeQuery();

			if (rs.next()) {
			    String currentBal = rs.getString("payment");
			    System.out.println("Your payment: " + currentBal);
			} else {
			    System.out.println("Account not found or no balance available.");
			}

			rs.close();
			ps1.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

		

}