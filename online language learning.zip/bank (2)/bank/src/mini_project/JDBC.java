package mini_project;
import java.sql.*;

public class JDBC {

	
	String url = "jdbc:mysql://localhost:3306/lang1";
	String userName="root";
	String password="727721euit089@F";
	private Connection con;
	JDBC()
	{
		try
		{
			this.con = DriverManager.getConnection(url, userName, password);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	public Connection getcon()
	{
		return con;
	}
	
}