package mini_project;

import java.util.*;
import java.sql.*;

public class withdraw {

    public void searchLanguage() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the language to search: ");
        String language = sc.nextLine();
        final JDBC jd = new JDBC();
        Connection con = null;
        try {
        	 con = jd.getcon(); // Assuming you have a method in the JDBC class to get the connection
            PreparedStatement preparedStatement = con.prepareStatement("SELECT name, mobile_number,email FROM admin_login1 WHERE language = ?");
            preparedStatement.setString(1, language);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Language found in the table, print the name, email, and mobile
                String name = resultSet.getString("name");
                String mobile = resultSet.getString("mobile_number");
                String email = resultSet.getString("email");

                System.out.println("Name: " + name);
                System.out.println("Email: " + email);
                System.out.println("Mobile: " + mobile);
            } else {
                System.out.println("Not Found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

